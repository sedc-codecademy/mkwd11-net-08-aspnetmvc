﻿namespace SEDC.PizzaApp.Models.ViewModels
{
    public class UserSelectViewModel
    {
        public int Id { get; set; } //value for the value attribute of the option tag
        public string UserFullname { get; set; } // value for the text of the option tag
    }
}
