﻿namespace SEDC.PizzaApp.Models.Enums
{
    public enum PaymentMethod
    {
        Cash =1,
        Card
    }
}
